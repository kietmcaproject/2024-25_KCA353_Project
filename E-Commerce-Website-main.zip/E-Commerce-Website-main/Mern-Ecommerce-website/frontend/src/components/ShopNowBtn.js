import React from 'react'

const ShopNowBtn = () => {
    return (
            <button className="ShopNow">
                SHOP NOW
                </button>
        
    )
}

export default ShopNowBtn
