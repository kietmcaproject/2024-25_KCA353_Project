import React from 'react';

const NotFoundPage = () => {
  return <h1>404 Page NotFound</h1>;
}

export default NotFoundPage;