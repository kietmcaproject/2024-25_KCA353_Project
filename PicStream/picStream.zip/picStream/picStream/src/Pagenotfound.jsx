import React from 'react'

const Pagenotfound = () => {
  return (
    <>
   <div className="mainerror">
    <h1>404</h1>
    <p>OOPS! NOTHING WAS FOUND</p>
   </div>
    </>
  )
}

export default Pagenotfound